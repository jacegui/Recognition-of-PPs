# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 20:57:40 2023

@author: jacegui
"""

import pandas as pd,os

#------
fw = open('link_专利间引用.txt','w',encoding='utf-8')
fw.write('p1\tp2\n')

df = pd.read_excel('IAHP-data_被引用专利.xlsx')

for i in range(df.shape[0]):
    temp = df.at[i,'被引用专利'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(df.at[i,'公开(公告)号'],p))
fw.close()

#------
fw = open('link_发明人和专利.txt','w',encoding='utf-8')
fw.write('p1\tp2\n')

df = pd.read_excel('IAHP-data_source_1.xlsx')

for i in range(df.shape[0]):
    temp = df.at[i,'所有发明人'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(p,df.at[i,'公开(公告)号']))
fw.close()

#------
fw = open('link_申请人和专利.txt','w',encoding='utf-8')
fw.write('p1\tp2\n')

df = pd.read_excel('IAHP-data_source_1.xlsx')

for i in range(df.shape[0]):
    temp = df.at[i,'所有申请人'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(p,df.at[i,'公开(公告)号']))
fw.close()

#------
fw = open('link_申请人和发明人.txt','w',encoding='utf-8')
fw.write('p1\tp2\n')

df = pd.read_excel('IAHP-data_source_1.xlsx')

for i in range(df.shape[0]):
    temp = df.at[i,'所有发明人'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(df.at[i,'第一申请人'],p))
fw.close()

#------
fw = open('link_发明人之间.txt','w',encoding='utf-8')
fw.write('p1\tp2\n')

df = pd.read_excel('IAHP-data_source_1.xlsx')

for i in range(df.shape[0]):
    temp = df.at[i,'所有发明人'].split(' | ')
    for i in range(len(temp)-1):
        for j in range(i+1, len(temp)):
            fw.write('{}\t{}\n'.format(temp[i],temp[j]))

#------
fw = open('link_发明人成果被引.txt','w',encoding='utf-8')
fw.write('p1\tp2\n')

df = pd.read_excel('IAHP-data_被引用专利.xlsx')

df_1 = pd.read_excel('IAHP-data_source_1.xlsx')

for i in range(df.shape[0]):
    temp = df.at[i,'被引用专利'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(df.at[i,'公开(公告)号'],p))
for i in range(df_1.shape[0]):
    temp = df_1.at[i,'所有发明人'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(p,df_1.at[i,'公开(公告)号']))
fw.close()

#------
fw = open('link_申请人成果被引.txt','w',encoding='utf-8')
fw.write('p1\tp2\n')

df = pd.read_excel('IAHP-data_被引用专利.xlsx')

df_1 = pd.read_excel('IAHP-data_source_1.xlsx')

for i in range(df.shape[0]):
    temp = df.at[i,'被引用专利'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(df.at[i,'公开(公告)号'],p))

for i in range(df_1.shape[0]):
    temp = df_1.at[i,'所有申请人'].split(' | ')
    for p in temp:
        fw.write('{}\t{}\n'.format(p,df_1.at[i,'公开(公告)号']))
fw.close()

