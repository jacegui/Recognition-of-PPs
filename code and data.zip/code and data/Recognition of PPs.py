# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 20:57:40 2023

@author: jacegui
"""

import pandas as pd

import numpy as np


topic_array = pd.read_excel(r'topic_result_ev_u.xlsx')

df_chp = pd.read_excel(r'EV_u_data_IAHP.xlsx')
IAHP_features = df_chp.columns[:-1].tolist()
IAHP_features = df_chp[IAHP_features].values

text_IAHP_features = np.hstack((topic_array,IAHP_features))

df_ea = pd.read_excel(r'EV_u_data_bibliometric.xlsx')
bibliometric_features = df_ea.columns[:-1].tolist()
bibliometric_features = df_ea[bibliometric_features].values

bibliometric_text_IAHP_features = np.hstack((bibliometric_features,text_IAHP_features))

bibliometric_IAHP_features = np.hstack((bibliometric_features,IAHP_features))

bibliometric_text_features = np.hstack((bibliometric_features,topic_array))


def PPs_prediction(features):
    df_label = pd.read_excel(r'EV_u_data_label.xlsx')
    data_label = df_label['class'].values
    PPs_feature = list()
    PPs_label = list()
    for i in range(df_label.shape[0]):
        if data_label[i] > 0:
            PPs_feature.append(list(features[i]))
            PPs_label.append(1)
    NPPs_feature = list()
    NPPs_label = list()
    for i in range(df_label.shape[0]):
        if data_label[i] == 0:
            NPPs_feature.append(list(features[i]))
            NPPs_label.append(0)
    for i in range(int(len(data_label)/10)):
        PPs_feature.append(NPPs_feature[i])
        PPs_label.append(0)
    d_feature = np.array(PPs_feature)
    d_label = np.array(PPs_label)
    from sklearn.preprocessing import normalize
    data_X = normalize(d_feature, axis=0, norm='max')
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(data_X, d_label, test_size=0.2)
    from sklearn.ensemble import RandomForestClassifier
    clf = RandomForestClassifier(n_estimators=16)
    clf.fit(X_train,y_train)
    predict_results=clf.predict(X_test)
    from sklearn.metrics import classification_report
    return classification_report(y_test, predict_results,digits=5)




print(PPs_prediction(topic_array))
print(PPs_prediction(IAHP_features))
print(PPs_prediction(bibliometric_features))
print(PPs_prediction(bibliometric_IAHP_features))
print(PPs_prediction(bibliometric_text_features))
print(PPs_prediction(text_IAHP_features))
print(PPs_prediction(bibliometric_text_IAHP_features))

import shap

shap_values = shap.TreeExplainer(clf).shap_values(X_train)

# features_1 = ['topic0','topic1','topic2','topic3','topic4','topic5','topic6','topic7','topic8','topic9','topic10','topic11','topic12','topic13','topic14']#------------
# features_1 = ['topic0','topic1','topic2','topic3','topic4','topic5','topic6','topic7']#------------
features_1 = ['topic0','topic1','topic2','topic3','topic4','topic5','topic6','topic7','topic8','topic9']#------------


shap.summary_plot(shap_values[1], X_train,features_1)

