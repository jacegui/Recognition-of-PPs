# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 20:57:40 2023

@author: jacegui
"""

import pandas as pd,os

df = pd.read_excel('EV_u.xlsx')

df_1 = df.iloc[:,[2]]

df_2 = df.iloc[:,[4]]

df_3 = df.iloc[:,[14]]

text = []

for i in range(df_1.shape[0]):
    temp = df_1.at[i,'标题'] + df_2.at[i,'第一权利要求'] + df_3.at[i,'摘要']
    text.append(temp)

from gensim.parsing.preprocessing import remove_stopwords

punc = [',','.',':',';','?','(',')','[',']','&','!','*','#','$','%','@']

from nltk.stem import WordNetLemmatizer

import nltk

doc_all = []

nltk.download('punkt')

for i in range(len(text)):
    temp_1 = remove_stopwords(text[i])
    temp = nltk.word_tokenize(temp_1)
    doc_new = [word for word in temp if word not in punc]
    doc_all.append(doc_new)

import matplotlib.pyplot as plt
import matplotlib

import gensim
from gensim import corpora
dic = corpora.Dictionary(doc_all)
doc_term_matrix = [dic.doc2bow(doc) for doc in doc_all]

Lda = gensim.models.LdaModel(doc_term_matrix,num_topics=8,id2word=dic,passes=10)

doc_topic = []
for i in range(len(text)):
    item_topic = Lda.get_document_topics(doc_term_matrix[i])
    doc_topic.append(item_topic)
    
import numpy as np

topic_array = np.zeros((len(text),8))

for i in range(len(text)):
    for j in range(len(doc_topic[i])):
        topic_array[i][doc_topic[i][j][0]] = doc_topic[i][j][1]


topic_result = pd.DataFrame(topic_array)

topic_result.to_csv('topic_result_ev_u.txt',sep='\t',header=None)#------------


