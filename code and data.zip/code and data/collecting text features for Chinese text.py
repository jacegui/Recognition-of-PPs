# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 20:57:40 2023

@author: jacegui
"""

import jieba
import numpy as np
import pandas as pd
stwlist = [line.strip() for line in open ('stop_words_1.txt',encoding='utf-8').readlines()]

import pandas as pd,os

df = pd.read_excel('E01_data.xlsx')#------------

df_1 = df.iloc[:,[1]]#------------

df_2 = df.iloc[:,[3]]#------------

df_3 = df.iloc[:,[15]]#------------

text = []

for i in range(df_1.shape[0]):
    temp = df_1.at[i,'标题'] + df_2.at[i,'第一权利要求'] + df_3.at[i,'摘要']
    text.append(temp)

doc_all = []

for i in range(len(text)):
    doc_words = jieba.cut(text[i],cut_all = False,HMM = True)
    doc_new = []
    for word in doc_words:
        if len(word)>1:
            if word.strip() not in stwlist:
                doc_new.append(word)
    doc_all.append(doc_new)


import gensim
from gensim import corpora
dic = corpora.Dictionary(doc_all)
doc_term_matrix = [dic.doc2bow(doc) for doc in doc_all]



Lda = gensim.models.LdaModel(doc_term_matrix,num_topics=10,id2word=dic,passes=10)#------------
topic_list = Lda.show_topics(num_topics=10,num_words=100,formatted=False)#------------

doc_topic = []
for i in range(len(text)):
    item_topic = Lda.get_document_topics(doc_term_matrix[i])
    doc_topic.append(item_topic)
    


topic_array = np.zeros((len(text),10))#------------

for i in range(len(text)):
    for j in range(len(doc_topic[i])):
        topic_array[i][doc_topic[i][j][0]] = doc_topic[i][j][1]


topic_result = pd.DataFrame(topic_array)

topic_result.to_csv('topic_result_e01.txt',sep='\t',header=None)#------------
