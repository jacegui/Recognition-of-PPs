# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 20:57:40 2023

@author: jacegui
"""

import pandas as pd,os

df = pd.read_excel('2000-2015_EV_u.xlsx')

#------
df_18 = df.iloc[:,[4]]

num_word_claim = []

for i in range(df_18.shape[0]):
    num_word_claim.append(len(df_18.at[i,'第一权利要求']))

#------
df_10 = df.iloc[:,[5]]

num_claim = []

for i in range(df_10.shape[0]):
    if df_10.at[i,'权利要求数'] == '-':
        num_claim.append(0)
    else:
        num_claim.append(int(df_10.at[i,'权利要求数']))

#------
df_13 = df.iloc[:,[20]]

num_assignee = []

for i in range(df_13.shape[0]):
    temp = df_13.at[i,'原始申请(专利权)人'].split(' | ')
    num_assignee.append(len(temp))

#------
df_12 = df.iloc[:,[7]]

num_inventor = []

for i in range(df_12.shape[0]):
    if df_12.at[i,'发明人数量'] == '-':
        num_inventor.append(0)
    else:
        num_inventor.append(int(df_12.at[i,'发明人数量']))

#------
df_14 = df.iloc[:,[3]]

num_ipc = []

for i in range(df_14.shape[0]):
    temp = df_14.at[i,'IPC分类号'].split(' | ')
    num_ipc.append(len(temp))

#------
df_16 = df.iloc[:,[8]]

num_simple = []

for i in range(df_16.shape[0]):
    num_simple.append(int(df_16.at[i,'简单同族成员数量']))

#------
df_19 = df.iloc[:,[9]]

num_INPADOC = []

for i in range(df_19.shape[0]):
    num_INPADOC.append(int(df_19.at[i,'INPADOC同族成员数量']))

#------
df_20 = df.iloc[:,[10]]

num_pro = []

for i in range(df_20.shape[0]):
    temp = df_20.at[i,'优先权号'].split(' | ')
    num_pro.append(len(temp))

#------
df_11 = df.iloc[:,[12]]

num_backward = []

for i in range(df_11.shape[0]):
    num_backward.append(int(df_11.at[i,'引用专利数量']))

#------
df_17 = df.iloc[:,[13]]

num_non_patent_citation = []

for i in range(df_17.shape[0]):
    num_non_patent_citation.append(int(df_17.at[i,'非专利引用文献数量']))


data_feature = []

data_feature.append(num_word_claim)
data_feature.append(num_claim)
data_feature.append(num_assignee)
data_feature.append(num_inventor)
data_feature.append(num_ipc)
data_feature.append(num_simple)
data_feature.append(num_INPADOC)
data_feature.append(num_pro)
data_feature.append(num_backward)
data_feature.append(num_non_patent_citation)



df_1 = pd.DataFrame(data_feature_1)

df_1.to_csv(r'EV_u_bibliometric_feature.txt',sep='\t',index=False,header=None)
