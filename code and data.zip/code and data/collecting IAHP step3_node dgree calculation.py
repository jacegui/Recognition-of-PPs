# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 20:57:40 2023

@author: jacegui
"""

#一阶度值
import networkx as nx

h = nx.read_edgelist(('input_申请人拥有发明人数量.txt'), create_using=nx.DiGraph())

fw = open('result_申请人拥有发明人数量.txt','w',encoding='utf-8')
fw.write('node\tf-d\n')
b = list(nx.nodes(h))
f_order_n = []

for tem in b:
    a = set(nx.neighbors(h,tem))
    fw.write('{}\t{}\n'.format(tem,len(a)))
fw.close()

#二阶度值
import networkx as nx

def CalculateDegree(G, node):
    nodes = list(nx.nodes(G))
    f_order_n = []
    s_order_n = []
    for f_n in list(nx.neighbors(G, node)):
        f_order_n .append(f_n)
    for item in f_order_n:
        for s_n in list(nx.neighbors(G, item)):
            s_order_n.append(s_n)
    s_order_n = list(set(s_order_n) - set(f_order_n))
    if node in s_order_n:
        s_order_n.remove(node)
    return s_order_n

fw = open('result_发明人成果被引次数.txt','w',encoding='utf-8')
fw.write('node\ts-d\n')

h = nx.read_edgelist(('input_发明人成果被引.txt'), create_using=nx.DiGraph())
b = list(nx.nodes(h))
for haha in range(496309,len(b)):#"496309" is the start node of inventor nodes in the list b.
    neighbors = CalculateDegree(h, b[haha])
    fw.write('{}\t{}\n'.format(b[haha],len(neighbors)))
fw.close()

#二阶度值均值
import networkx as nx
import numpy as np

def CalculateDegree(G, node):
    nodes = list(nx.nodes(G))
    f_order_n = []
    s_order_n = []
    for f_n in list(nx.neighbors(G, node)):
        f_order_n .append(f_n)
    for item in f_order_n:
        s_n_value = len(list(set(nx.neighbors(G, item))))
        s_order_n.append(s_n_value)
    if len(s_order_n) == 0:
        s_order_n.append(0)
    return s_order_n

fw = open('result_发明人成果被引均值_1.txt','w',encoding='utf-8')
fw.write('node\tmean_s-d\n')

h = nx.read_edgelist(('input_发明人成果被引.txt'), create_using=nx.DiGraph())
b = list(nx.nodes(h))

for haha in range(496309,len(b)):
    neighbors = CalculateDegree(h, b[haha])
    fw.write('{}\t{}\n'.format(b[haha],np.mean(neighbors)))
fw.close()

#二阶度值最大
import networkx as nx

def CalculateDegree(G, node):
    nodes = list(nx.nodes(G))
    f_order_n = []
    s_order_n = []
    for f_n in list(nx.neighbors(G, node)):
        f_order_n .append(f_n)
    for item in f_order_n:
        s_n_value = len(list(set(nx.neighbors(G, item))))
        s_order_n.append(s_n_value)
    if len(s_order_n) == 0:
        s_order_n.append(0)
    return s_order_n

fw = open('result_发明人成果被引最高.txt','w',encoding='utf-8')
fw.write('node\tmax_s-d\n')

h = nx.read_edgelist(('input_发明人成果被引.txt'), create_using=nx.DiGraph())
b = list(nx.nodes(h))

for haha in range(496309,len(b)):
    neighbors = CalculateDegree(h, b[haha])
    fw.write('{}\t{}\n'.format(b[haha],max(neighbors)))
fw.close()
