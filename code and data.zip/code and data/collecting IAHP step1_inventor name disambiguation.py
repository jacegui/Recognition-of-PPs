# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 20:57:40 2023

@author: jacegui
"""

import pandas as pd,os
import datetime
df = pd.read_excel(r'EV_u_selected-data.xlsx')
ls = list(df['inventor'])
ns = list(df['applicant'])
contain = ["!"]
for w in range(len(ls)-1):
    temp = ls[w].split(' | ')
    for i in range(len(temp)):
        if temp[i] not in contain:
            for s in range(w+1,len(ls)):
                 tem = ls[s].split(' | ')
                 for j in range(len(tem)):
                     if tem[j] == temp[i]:
                         if ns[w] == ns[s]:
                             tem[j] = temp[i] + str(w)
                             ls[s] = " | ".join(tem)
            temp[i] = temp[i] + str(w)
            contain.append(temp[i])
    ls[w] = " | ".join(temp)
df = pd.DataFrame(ls)
df.to_csv('result_EV_u_data.txt',sep='\t',index=False,header=None)
